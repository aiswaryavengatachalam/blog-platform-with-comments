const express=require("express");
const path=require("path");
const crypto=require("crypto");
const app=express();
const PORT=process.env.PORT||3000;
app.use(express.json());app.use(express.static(path.join(__dirname,"public")));

const users=[];const sessions=new Map();const posts=[];
const hash=p=>crypto.createHash("sha256").update(p).digest("hex");
function auth(req,res,next){const t=(req.headers.authorization||"").replace("Bearer ","");const uid=sessions.get(t);if(!uid)return res.status(401).json({message:"Login required"});req.user=users.find(u=>u.id===uid);next()}

app.post("/api/auth/register",(req,res)=>{
 const {name,email,password}=req.body;if(!name||!email||!password)return res.status(400).json({message:"All fields are required"});
 if(users.some(u=>u.email.toLowerCase()===email.toLowerCase()))return res.status(409).json({message:"Email already registered"});
 users.push({id:crypto.randomUUID(),name,email,password:hash(password)});res.status(201).json({message:"Registration successful. Please login."});
});
app.post("/api/auth/login",(req,res)=>{
 const {email,password}=req.body,user=users.find(u=>u.email.toLowerCase()===String(email).toLowerCase()&&u.password===hash(password));
 if(!user)return res.status(401).json({message:"Invalid email or password"});
 const token=crypto.randomUUID();sessions.set(token,user.id);res.json({token,name:user.name});
});
app.get("/api/posts",(req,res)=>{
 const t=(req.headers.authorization||"").replace("Bearer ",""),uid=sessions.get(t);
 res.json(posts.map(p=>({...p,owned:uid===p.userId,comments:p.comments||[]})));
});
app.get("/api/posts/:id",auth,(req,res)=>{
 const p=posts.find(x=>x.id===req.params.id);if(!p)return res.status(404).json({message:"Post not found"});
 res.json(p);
});
app.post("/api/posts",auth,(req,res)=>{
 const {title,content}=req.body;if(!title||!content)return res.status(400).json({message:"Title and content are required"});
 const p={id:crypto.randomUUID(),title,content,userId:req.user.id,author:req.user.name,comments:[],createdAt:new Date().toISOString()};
 posts.unshift(p);res.status(201).json(p);
});
app.put("/api/posts/:id",auth,(req,res)=>{
 const p=posts.find(x=>x.id===req.params.id&&x.userId===req.user.id);if(!p)return res.status(404).json({message:"Post not found or unauthorized"});
 p.title=req.body.title||p.title;p.content=req.body.content||p.content;res.json(p);
});
app.delete("/api/posts/:id",auth,(req,res)=>{
 const i=posts.findIndex(x=>x.id===req.params.id&&x.userId===req.user.id);if(i<0)return res.status(404).json({message:"Post not found or unauthorized"});
 posts.splice(i,1);res.json({message:"Post deleted"});
});
app.post("/api/posts/:id/comments",auth,(req,res)=>{
 const p=posts.find(x=>x.id===req.params.id);if(!p)return res.status(404).json({message:"Post not found"});
 if(!req.body.text)return res.status(400).json({message:"Comment cannot be empty"});
 const c={id:crypto.randomUUID(),author:req.user.name,text:req.body.text,createdAt:new Date().toISOString()};p.comments.push(c);res.status(201).json(c);
});
app.listen(PORT,()=>console.log("BlogHub running on http://localhost:"+PORT));