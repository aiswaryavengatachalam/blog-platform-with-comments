# Blog Platform with Comments

A complete responsive full-stack blogging platform.

## Features
- User registration and login
- Authentication and authorization
- Create, read, update and delete blog posts
- Comments and user interaction
- RESTful APIs
- Responsive desktop/mobile UI
- Owner-only edit/delete controls

## Tech Stack
HTML5, CSS3, JavaScript, Node.js, Express.js.

## Run
1. Install Node.js.
2. Open terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000

## Database
The application uses an in-memory data layer for a zero-configuration demo. For production, the arrays in `server.js` can be replaced with MongoDB/PostgreSQL/MySQL models without changing the frontend API structure.

## GitHub Repository
blog-platform-with-comments
