let token=localStorage.getItem("bloghub_token"), editingId=null, register=false;
const $=id=>document.getElementById(id);
function headers(json=false){const h={};if(json)h["Content-Type"]="application/json";if(token)h.Authorization="Bearer "+token;return h}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

$("switchAuth").onclick=()=>{register=!register;updateAuth()};
function updateAuth(){$("authHeading").textContent=register?"Create account":"Login";$("authBtn").textContent=register?"Register":"Login";$("switchAuth").textContent=register?"Already have an account? Login":"Create an account";$("nameWrap").classList.toggle("hide",!register)}
$("authBtn").onclick=async()=>{
 const body={email:$("email").value,password:$("password").value};if(register)body.name=$("name").value;
 const r=await fetch(register?"/api/auth/register":"/api/auth/login",{method:"POST",headers:headers(true),body:JSON.stringify(body)}),d=await r.json();$("authMsg").textContent=d.message;
 if(r.ok&&!register){token=d.token;localStorage.setItem("bloghub_token",token);refreshAuth()}
 if(r.ok&&register){register=false;updateAuth()}
};
$("logout").onclick=()=>{token=null;localStorage.removeItem("bloghub_token");editingId=null;refreshAuth();loadPosts()};
function refreshAuth(){const logged=!!token;$("auth").classList.toggle("hide",logged);$("editor").classList.toggle("hide",!logged);$("logout").classList.toggle("hide",!logged);$("userBox").textContent=logged?"Signed in":""}
$("savePost").onclick=async()=>{
 const title=$("title").value.trim(),content=$("content").value.trim();if(!title||!content)return alert("Enter title and content");
 const url=editingId?"/api/posts/"+editingId:"/api/posts",method=editingId?"PUT":"POST";
 const r=await fetch(url,{method,headers:headers(true),body:JSON.stringify({title,content})});const d=await r.json();
 if(!r.ok)return alert(d.message);resetEditor();loadPosts()
};
$("cancelEdit").onclick=resetEditor;
function resetEditor(){editingId=null;$("editorHeading").textContent="Create a Post";$("savePost").textContent="Publish Post";$("cancelEdit").classList.add("hide");$("title").value="";$("content").value=""}
async function loadPosts(){
 const r=await fetch("/api/posts"),posts=await r.json();$("postList").innerHTML=posts.length?posts.map(post=>`
 <article class="post"><h3>${escapeHtml(post.title)}</h3><div class="meta">By ${escapeHtml(post.author)} · ${new Date(post.createdAt).toLocaleString()}</div>
 <div class="post-content">${escapeHtml(post.content)}</div>
 ${token&&post.owned?`<div class="actions"><button class="edit" onclick="editPost('${post.id}')">Edit</button> <button class="danger" onclick="deletePost('${post.id}')">Delete</button></div>`:""}
 <h4>Comments (${post.comments.length})</h4>${post.comments.map(c=>`<div class="comment"><b>${escapeHtml(c.author)}</b> · ${escapeHtml(c.text)}</div>`).join("")}
 ${token?`<div class="commentForm"><input id="c-${post.id}" placeholder="Write a comment"><button onclick="addComment('${post.id}')">Comment</button></div>`:"<small>Login to comment.</small>"}</article>`).join(""):"<p>No posts yet. Be the first to write!</p>"
}
async function editPost(id){const r=await fetch("/api/posts/"+id,{headers:headers()}),p=await r.json();if(!r.ok)return alert(p.message);editingId=id;$("editorHeading").textContent="Edit Post";$("savePost").textContent="Update Post";$("cancelEdit").classList.remove("hide");$("title").value=p.title;$("content").value=p.content;location.hash="editor"}
async function deletePost(id){if(!confirm("Delete this post?"))return;const r=await fetch("/api/posts/"+id,{method:"DELETE",headers:headers()});if(!r.ok){const d=await r.json();return alert(d.message)}loadPosts()}
async function addComment(id){const input=$("c-"+id),text=input.value.trim();if(!text)return;const r=await fetch("/api/posts/"+id+"/comments",{method:"POST",headers:headers(true),body:JSON.stringify({text})});if(!r.ok){const d=await r.json();return alert(d.message)}loadPosts()}
updateAuth();refreshAuth();loadPosts();